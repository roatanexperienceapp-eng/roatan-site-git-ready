# Roatan Experience App — Website

Single-file static website for booking Roatán excursions (excursion catalog, filtering/search, booking inquiry modal, cruise ship arrival schedule, multi-language switcher).

## Structure
- `index.html` — the entire site (HTML, CSS via Tailwind CDN, and vanilla JS). No build step required.

## Deploy on Vercel
1. Push this repo to GitHub (see below).
2. In Vercel: **Add New → Project → Import Git Repository** → select this repo.
3. Leave all settings as default (no framework, no build command needed) → **Deploy**.
4. Any future edit pushed to this repo's main branch will auto-redeploy.

## Known TODO before real launch
- The booking form (`submitBooking()` in `index.html`) currently only logs the request to the browser console — it is **not** wired to a backend, email service, or database yet. Bookings will not reach you until this is connected (e.g. Formspree, EmailJS, or a custom API).
- Contact details (email, WhatsApp, Zelle) are already live in the top bar, footer, and booking modal.
